package dev.tether.app

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import dev.tether.core.RemoteCommands

/** Runs the computer's saved commands, or free-form shell when the computer allows it, and shows the output. */
class CommandsActivity : Activity() {
    companion object {
        const val EXTRA_PEER = "peer"
    }

    private lateinit var buttons: LinearLayout
    private lateinit var shellRow: LinearLayout
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var outputScroll: ScrollView
    private var remote: RemoteCommands? = null
    private var busy = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val peer = intent?.getStringExtra(EXTRA_PEER)
        val node = Hub.node
        if (peer == null || node == null) {
            finish()
            return
        }
        remote = RemoteCommands(node, peer)
        title = "Commands on ${node.peers.get(peer)?.name ?: "computer"}"

        buttons = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        input = EditText(this).apply {
            hint = "Shell command"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
            typeface = Typeface.MONOSPACE
        }
        shellRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(Button(this@CommandsActivity).apply {
                text = "Run"
                isAllCaps = false
                setOnClickListener {
                    val line = input.text?.toString()?.trim().orEmpty()
                    if (line.isNotEmpty()) execute("$ $line") { it.shell(line) }
                }
            })
        }
        output = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 13f
            setTextIsSelectable(true)
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        outputScroll = ScrollView(this).apply { addView(output) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
            addView(buttons)
            addView(shellRow)
            addView(
                outputScroll,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f),
            )
        }
        setContentView(root)
        load()
    }

    private fun load() {
        val rc = remote ?: return
        output.text = "Loading…"
        Thread {
            try {
                val listing = rc.list()
                runOnUiThread { show(listing) }
            } catch (e: Exception) {
                runOnUiThread { output.text = "Couldn't reach the computer: ${e.message}" }
            }
        }.start()
    }

    private fun show(listing: RemoteCommands.Listing) {
        buttons.removeAllViews()
        for (c in listing.commands) {
            buttons.addView(Button(this).apply {
                text = c.name
                isAllCaps = false
                setOnClickListener { execute("▶ ${c.name}") { it.run(c.id) } }
            })
        }
        shellRow.visibility = if (listing.shell) View.VISIBLE else View.GONE
        val hints = mutableListOf<String>()
        if (listing.commands.isEmpty()) {
            hints += "No saved commands. Add some on the computer:\n  tether command add \"Lock screen\" 'loginctl lock-session'"
        }
        if (!listing.shell) {
            hints += "Free-form commands are off. To allow them, run on the computer:\n  tether set remote_shell on"
        }
        output.text = hints.joinToString("\n\n")
    }

    private fun execute(label: String, run: (RemoteCommands) -> RemoteCommands.Result) {
        val rc = remote ?: return
        if (busy) return
        busy = true
        append(if (output.text.isNullOrEmpty()) "$label\n" else "\n$label\n")
        Thread {
            val text = try {
                val r = run(rc)
                buildString {
                    if (r.output.isNotEmpty()) append(r.output.trimEnd()).append('\n')
                    if (r.truncated) append("[output truncated]\n")
                    append(
                        when {
                            r.timedOut -> "[stopped: took too long]"
                            r.exit == 0 -> "[done]"
                            else -> "[exit ${r.exit}]"
                        },
                    )
                    append('\n')
                }
            } catch (e: Exception) {
                "[failed: ${e.message}]\n"
            }
            runOnUiThread {
                append(text)
                busy = false
            }
        }.start()
    }

    private fun append(s: String) {
        output.append(s)
        outputScroll.post { outputScroll.fullScroll(View.FOCUS_DOWN) }
    }
}
