package dev.tether.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.provider.DocumentsContract
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import dev.tether.core.Node
import dev.tether.core.NodeEvent
import dev.tether.core.SyncFolder

class MainActivity : Activity() {
    companion object {
        const val EXTRA_PAIR = "pair"
        private const val REQ_SEND = 1
        private const val REQ_SHARE_TREE = 2
        private const val REQ_SYNC_TREE = 3
    }

    private lateinit var content: LinearLayout
    private var pairDialog: AlertDialog? = null
    private var sendTarget: String? = null
    private var pendingPairPrompt: String? = null
    private val listener: (NodeEvent) -> Unit = { onNodeEvent(it) }

    // -- lifecycle ------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Hub.start(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(32))
        }
        val scroll = ScrollView(this)
        scroll.addView(content)
        setContentView(scroll)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        pendingPairPrompt = intent?.getStringExtra(EXTRA_PAIR)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingPairPrompt = intent.getStringExtra(EXTRA_PAIR)
        render()
    }

    override fun onResume() {
        super.onResume()
        Hub.addListener(listener)
        render()
    }

    override fun onPause() {
        Hub.removeListener(listener)
        super.onPause()
    }

    private fun onNodeEvent(e: NodeEvent) {
        when (e) {
            is NodeEvent.PairRequest -> showPairDialog(e.id, e.name, e.sas)
            is NodeEvent.Paired -> {
                pairDialog?.dismiss()
                toast("Paired with ${e.name}")
            }
            is NodeEvent.PairFailed -> {
                pairDialog?.dismiss()
                toast("Pairing ${if (e.reason == "timeout") "timed out" else "was cancelled"}")
            }
            else -> {}
        }
        render()
    }

    // -- UI helpers ---------------------------------------------------------------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val accent: Int by lazy {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.colorAccent, tv, true)
        tv.data
    }

    private fun header(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        isAllCaps = true
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(accent)
        setPadding(0, dp(24), 0, dp(6))
    }

    private fun body(text: CharSequence, selectable: Boolean = false, small: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = if (small) 13f else 15f
        setPadding(0, dp(4), 0, dp(4))
        setTextIsSelectable(selectable)
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun row(label: View, vararg actions: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        actions.forEach { addView(it) }
    }

    private fun add(v: View) = content.addView(v)

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    /** Runs network or disk work off the main thread; errors become toasts. */
    private fun bg(work: () -> Unit) {
        Thread {
            try {
                work()
            } catch (e: Exception) {
                runOnUiThread { toast(e.message ?: e.javaClass.simpleName) }
            }
        }.start()
    }

    private fun prompt(title: String, initial: String, hint: String, onOk: (String) -> Unit) {
        val input = EditText(this).apply {
            setText(initial)
            this.hint = hint
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        val frame = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(frame)
            .setPositiveButton("OK") { _, _ -> input.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(onOk) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // -- rendering ------------------------------------------------------------------------

    private fun render() {
        content.removeAllViews()
        val node = Hub.node
        if (node == null) {
            add(body("Starting…"))
            content.postDelayed({ if (!isFinishing) render() }, 500)
            return
        }
        renderDevice(node)
        renderComputers(node)
        renderClipboard(node)
        renderNotifications(node)
        renderFiles(node)
        renderBackground()
        pendingPairPrompt?.let { id ->
            node.pendingPairs().firstOrNull { it.id == id && !it.confirmed }?.let { showPairDialog(it.id, it.name, it.sas) }
            pendingPairPrompt = null
        }
    }

    private fun renderDevice(node: Node) {
        add(header("This phone"))
        add(
            row(
                body("${node.settings.name}\nID ${node.identity.id.take(8)}"),
                button("Rename") {
                    prompt("Device name", node.settings.name, "Name shown on your computer") {
                        node.settings.name = it
                        node.settings.save()
                        render()
                    }
                },
            ),
        )
    }

    private fun renderComputers(node: Node) {
        add(header("Computers"))
        val peers = node.peers.all()
        if (peers.isEmpty()) add(body("No paired computers yet."))
        for (p in peers) {
            val online = node.isConnected(p.id)
            val label = body("${if (online) "●" else "○"} ${p.name}\n${if (online) "Connected" else "Not connected"}")
            val actions = mutableListOf<View>()
            if (online) {
                actions += button("Media") {
                    startActivity(Intent(this, MediaActivity::class.java).putExtra(MediaActivity.EXTRA_PEER, p.id))
                }
                actions += button("Commands") {
                    startActivity(Intent(this, CommandsActivity::class.java).putExtra(CommandsActivity.EXTRA_PEER, p.id))
                }
                actions += button("Send files") {
                    sendTarget = p.id
                    @Suppress("DEPRECATION")
                    startActivityForResult(
                        Intent(Intent.ACTION_OPEN_DOCUMENT)
                            .addCategory(Intent.CATEGORY_OPENABLE)
                            .setType("*/*")
                            .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true),
                        REQ_SEND,
                    )
                }
            }
            actions += button("Unpair") {
                AlertDialog.Builder(this)
                    .setTitle("Unpair ${p.name}?")
                    .setMessage("You'll need to pair again to reconnect.")
                    .setPositiveButton("Unpair") { _, _ -> bg { node.unpair(p.id) } }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            add(row(label, *actions.toTypedArray()))
        }
        for (pp in node.pendingPairs()) {
            add(
                row(
                    body("Pairing with ${pp.name}…\nCode ${pp.sas.substring(0, 3)} ${pp.sas.substring(3)}"),
                    button(if (pp.confirmed) "Waiting" else "Confirm") {
                        if (!pp.confirmed) showPairDialog(pp.id, pp.name, pp.sas)
                    },
                ),
            )
        }
        val nearby = node.discovery.recent().filter { !node.peers.contains(it.id) }
        if (nearby.isNotEmpty()) add(body("Nearby", small = true))
        for (d in nearby) {
            add(row(body("${d.name}\n${d.host}"), button("Pair") { bg { node.startPairing(peerId = d.id) } }))
        }
        add(
            button("Pair by IP address") {
                prompt("Computer's address", "", "192.168.1.20") { addr -> bg { node.startPairing(address = addr) } }
            },
        )
        if (peers.isEmpty() && nearby.isEmpty()) {
            add(body("Start the Tether daemon on your computer and run “tether pair”, or tap Pair when it appears here.", small = true))
        }
    }

    private fun renderClipboard(node: Node) {
        add(header("Clipboard"))
        add(
            Switch(this).apply {
                text = "Sync clipboard"
                textSize = 15f
                isChecked = node.settings.clipboard
                setOnCheckedChangeListener { _, checked ->
                    node.settings.clipboard = checked
                    node.settings.save()
                }
            },
        )
        add(button("Send clipboard now") { sendClipboardNow() })
        if (TetherService.autoClipboardAvailable(this)) {
            add(body("Automatic: copying anything on the phone sends it to your computer.", small = true))
        } else {
            add(
                body(
                    "From computer to phone is automatic. Android only lets apps read the clipboard while " +
                        "they're open, so from phone to computer use “Send clipboard now”, the Quick Settings tile, " +
                        "or “Send to computer” in the text-selection menu.\n\nFor fully automatic sync, run once " +
                        "from your computer with USB debugging on, then restart Tether:",
                    small = true,
                ),
            )
            val cmds = "adb shell pm grant $packageName android.permission.READ_LOGS\n" +
                "adb shell appops set $packageName SYSTEM_ALERT_WINDOW allow"
            add(body(cmds, selectable = true, small = true).apply { typeface = Typeface.MONOSPACE })
            add(
                row(
                    View(this),
                    button("Copy commands") {
                        Hub.lastRemoteClip = cmds
                        getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("adb", cmds))
                        toast("Copied")
                    },
                    button("Restart Tether") { restartService() },
                ),
            )
        }
    }

    private fun renderNotifications(node: Node) {
        add(header("Notifications"))
        if (!NotifListener.enabled(this)) {
            add(body("Show this phone's notifications on your computer, and reply to messages from there. " +
                "Tether needs notification access for that.", small = true))
            add(button("Allow notification access") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            })
            return
        }
        add(
            Switch(this).apply {
                text = "Show notifications on the computer"
                textSize = 15f
                isChecked = node.settings.forwardNotifications
                setOnCheckedChangeListener { _, checked ->
                    node.settings.forwardNotifications = checked
                    node.settings.save()
                }
            },
        )
        add(body("Choose which apps appear in Tether's Settings on the computer.", small = true))
    }

    private fun renderFiles(node: Node) {
        add(header("Files"))
        if (!Environment.isExternalStorageManager()) {
            add(body("Allow access to all files so your computer can browse and sync folders.", small = true))
            add(
                button("Allow all-files access") {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")),
                    )
                },
            )
        }
        add(body("Received files are saved in Download/Tether. Your computer's shared folders appear in the Files app under its name.", small = true))

        add(body("Shared with your computer", small = true).apply { setTypeface(typeface, Typeface.BOLD) })
        for ((name, path) in node.settings.shares) {
            add(
                row(
                    body("$name\n$path", small = true),
                    button("Remove") { node.updateShares(node.settings.shares - name); render() },
                ),
            )
        }
        add(
            button("Share a folder") {
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_SHARE_TREE)
            },
        )

        add(body("Synced folders", small = true).apply { setTypeface(typeface, Typeface.BOLD) })
        for (f in node.settings.sync) {
            add(
                row(
                    body("${f.id}\n${f.path}", small = true),
                    button("Remove") { node.updateSyncFolders(node.settings.sync.filter { it.id != f.id }); render() },
                ),
            )
        }
        add(
            button("Sync a folder") {
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_SYNC_TREE)
            },
        )
        add(body("On the computer, add the same folder name: tether sync add NAME ~/some/folder", small = true))
    }

    private fun renderBackground() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
            add(header("Background"))
            add(body("Let Tether run in the background so it stays connected.", small = true))
            add(
                button("Allow background activity") {
                    @Suppress("BatteryLife")
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")),
                    )
                },
            )
        }
    }

    // -- actions --------------------------------------------------------------------------

    private fun showPairDialog(id: String, name: String, sas: String) {
        if (isFinishing) return
        pairDialog?.dismiss()
        pairDialog = AlertDialog.Builder(this)
            .setTitle("Pair with $name?")
            .setMessage("Check that your computer shows the same code:\n\n${sas.substring(0, 3)} ${sas.substring(3)}")
            .setPositiveButton("Codes match") { _, _ -> bg { Hub.node?.confirmPairing(id, true) } }
            .setNegativeButton("Cancel") { _, _ -> bg { Hub.node?.confirmPairing(id, false) } }
            .setCancelable(false)
            .show()
    }

    private fun sendClipboardNow() {
        if (Hub.computers().isEmpty()) {
            toast("No computer connected")
            return
        }
        when (ClipCapture.capture(this, force = true)) {
            null -> toast("The clipboard is empty")
            "image" -> toast("Image sent")
            else -> toast("Clipboard sent")
        }
    }

    private fun restartService() {
        stopService(Intent(this, TetherService::class.java))
        content.postDelayed({ Hub.start(this); render() }, 800)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val node = Hub.node ?: return
        when (requestCode) {
            REQ_SEND -> {
                val uris = mutableListOf<Uri>()
                val clip = data.clipData
                if (clip != null) for (i in 0 until clip.itemCount) clip.getItemAt(i)?.uri?.let { uris += it }
                data.data?.let { if (uris.isEmpty()) uris += it }
                val target = sendTarget ?: return
                Transfers.send(this, target, uris) { ok, msg -> runOnUiThread { toast(msg) } }
            }
            REQ_SHARE_TREE -> {
                val path = treeToPath(data.data) ?: return toast("That location can't be shared")
                var name = path.trimEnd('/').substringAfterLast('/').ifEmpty { "Storage" }
                while (node.settings.shares.containsKey(name)) name += "+"
                node.updateShares(node.settings.shares + (name to path))
                render()
            }
            REQ_SYNC_TREE -> {
                val path = treeToPath(data.data) ?: return toast("That location can't be synced")
                val suggested = path.trimEnd('/').substringAfterLast('/').lowercase()
                    .replace(Regex("[^a-z0-9_-]"), "-").trim('-').ifEmpty { "folder" }
                prompt("Folder name (same on both devices)", suggested, "e.g. camera") { raw ->
                    val id = raw.lowercase().replace(Regex("[^a-z0-9_-]"), "-")
                    node.updateSyncFolders(node.settings.sync.filter { it.id != id } + SyncFolder(id, path))
                    toast("Now run on your computer: tether sync add $id ~/path")
                    render()
                }
            }
        }
    }

    /** Converts a document-tree URI from the system picker into a filesystem path. */
    private fun treeToPath(uri: Uri?): String? {
        if (uri == null) return null
        val docId = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrNull() ?: return null
        val volume = docId.substringBefore(':')
        val rel = docId.substringAfter(':', "")
        val base = if (volume == "primary") Environment.getExternalStorageDirectory().path else "/storage/$volume"
        return if (rel.isEmpty()) base else "$base/$rel"
    }
}
