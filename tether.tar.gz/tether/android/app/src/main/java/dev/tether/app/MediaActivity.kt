package dev.tether.app

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import dev.tether.core.MediaState
import dev.tether.core.NodeEvent
import dev.tether.core.RemoteMedia

/** Remote control for whatever is playing on a computer. */
class MediaActivity : Activity() {
    companion object {
        const val EXTRA_PEER = "peer"
    }

    private var peer: String = ""
    private var remote: RemoteMedia? = null
    private var state: MediaState? = null
    private var dragging = false
    private var volumeDragging = false

    private lateinit var playerLabel: TextView
    private lateinit var titleLabel: TextView
    private lateinit var artistLabel: TextView
    private lateinit var timeLabel: TextView
    private lateinit var seek: SeekBar
    private lateinit var playPause: Button
    private lateinit var volume: SeekBar
    private lateinit var controls: LinearLayout

    private val listener: (NodeEvent) -> Unit = { e ->
        if (e is NodeEvent.MediaUpdate && e.from == peer) show(e.state)
    }
    private val ticker = object : Runnable {
        override fun run() {
            updatePosition()
            seek.postDelayed(this, 500)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 18f
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val node = Hub.node
        peer = intent?.getStringExtra(EXTRA_PEER) ?: ""
        if (node == null || peer.isEmpty()) {
            finish()
            return
        }
        remote = RemoteMedia(node, peer)
        title = "Media on ${node.peers.get(peer)?.name ?: "computer"}"

        playerLabel = TextView(this).apply { textSize = 13f; gravity = Gravity.CENTER }
        titleLabel = TextView(this).apply {
            textSize = 22f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(12), 0, dp(4))
        }
        artistLabel = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER }
        seek = SeekBar(this).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {}
                override fun onStartTrackingTouch(bar: SeekBar?) {
                    dragging = true
                }
                override fun onStopTrackingTouch(bar: SeekBar?) {
                    dragging = false
                    val p = state?.active ?: return
                    send("position", p.name, (bar?.progress ?: 0).toLong() * 1000)
                }
            })
        }
        timeLabel = TextView(this).apply { textSize = 13f; gravity = Gravity.CENTER }

        playPause = button("Play") { send("play_pause", state?.active?.name) }
        controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(button("⏮") { send("previous", state?.active?.name) })
            addView(button("−10 s") { send("seek", state?.active?.name, -10) })
            addView(playPause)
            addView(button("+10 s") { send("seek", state?.active?.name, 10) })
            addView(button("⏭") { send("next", state?.active?.name) })
        }

        volume = SeekBar(this).apply {
            max = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {}
                override fun onStartTrackingTouch(bar: SeekBar?) {
                    volumeDragging = true
                }
                override fun onStopTrackingTouch(bar: SeekBar?) {
                    volumeDragging = false
                    send("volume", null, (bar?.progress ?: 0) / 100.0)
                }
            })
        }
        val volumeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@MediaActivity).apply { text = "Volume"; textSize = 15f })
            addView(volume, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(button("Mute") { send("mute", null) }.apply { textSize = 14f })
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            addView(playerLabel)
            addView(titleLabel)
            addView(artistLabel)
            addView(seek, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(20)
            })
            addView(timeLabel)
            addView(controls)
            addView(volumeRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(28)
            })
        }
        setContentView(root)
        titleLabel.text = "Loading…"
    }

    override fun onResume() {
        super.onResume()
        Hub.addListener(listener)
        seek.post(ticker)
        val rc = remote ?: return
        Thread {
            try {
                val st = rc.state()
                runOnUiThread { show(st) }
            } catch (e: Exception) {
                runOnUiThread { titleLabel.text = "Couldn't reach the computer" }
            }
        }.start()
    }

    override fun onPause() {
        Hub.removeListener(listener)
        seek.removeCallbacks(ticker)
        super.onPause()
    }

    private fun send(action: String, player: String?, value: Number? = null) {
        val rc = remote ?: return
        Thread {
            try {
                val st = rc.command(action, player, value)
                runOnUiThread { show(st) }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, e.message ?: "Failed", Toast.LENGTH_SHORT).show() }
            }
        }.start()
    }

    private fun fmt(ms: Long?): String {
        if (ms == null) return "–:––"
        val s = ms / 1000
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s / 60 % 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
    }

    private fun show(st: MediaState) {
        state = st
        val p = st.active
        if (!st.available) {
            titleLabel.text = "Media control isn't available"
            artistLabel.text = "Install playerctl on the computer"
        } else if (p == null) {
            playerLabel.text = ""
            titleLabel.text = "Nothing is playing"
            artistLabel.text = ""
        } else {
            playerLabel.text = p.identity + if (st.players.size > 1) "  (+${st.players.size - 1} more)" else ""
            titleLabel.text = p.title.ifEmpty { p.identity }
            artistLabel.text = listOf(p.artist, p.album).filter { it.isNotEmpty() }.joinToString(" — ")
            playPause.text = if (p.playing) "Pause" else "Play"
        }
        controls.visibility = if (p == null) View.INVISIBLE else View.VISIBLE
        seek.visibility = if (p?.lengthMs == null) View.INVISIBLE else View.VISIBLE
        if (!volumeDragging) st.volume?.let { volume.progress = (it * 100).toInt() }
        volume.isEnabled = st.volume != null
        updatePosition()
    }

    private fun updatePosition() {
        val p = state?.active ?: return
        val length = p.lengthMs
        val pos = p.positionNow()
        if (length != null && !dragging) {
            seek.max = (length / 1000).toInt().coerceAtLeast(1)
            seek.progress = ((pos ?: 0) / 1000).toInt()
        }
        timeLabel.text = "${fmt(pos)} / ${fmt(length)}"
    }
}
