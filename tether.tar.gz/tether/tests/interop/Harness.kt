// A stand-in "phone": the Android app's Kotlin core driven over stdin/stdout,
// so the Python test can exercise it against the Linux daemon.

import dev.tether.core.FileIdentity
import dev.tether.core.Node
import dev.tether.core.NodeEvent
import dev.tether.core.Platform
import dev.tether.core.RemoteFs
import dev.tether.core.Settings
import dev.tether.core.SyncFolder
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

fun main(args: Array<String>) {
    val home = File(args[0])
    val port = args[1].toInt()
    val share = args[2]
    val syncDir = args[3]
    val out = System.out
    fun emit(line: String) = synchronized(out) { out.println(line); out.flush() }

    val platform = object : Platform {
        override fun setClipboard(text: String) = emit("CLIP " + text.replace("\n", "\\n"))
        override fun downloadsDir() = File(home, "downloads")
        override fun onEvent(event: NodeEvent) {
            when (event) {
                is NodeEvent.PairRequest -> emit("PAIRREQ ${event.id} ${event.sas} ${event.initiator}")
                is NodeEvent.Paired -> emit("PAIRED ${event.id}")
                is NodeEvent.PairFailed -> emit("PAIRFAILED ${event.id} ${event.reason}")
                is NodeEvent.FileReceived -> emit("FILE ${event.file.path}")
                is NodeEvent.Unpaired -> emit("UNPAIRED ${event.id}")
                else -> {}
            }
        }
        override fun log(msg: String) = System.err.println("[kt] $msg")
    }
    File(home, "settings.json").writeText(
        """{"port": $port, "discovery_port": ${port + 2000}, "scan_interval": 1, "name": "KtPhone"}""",
    )
    val node = Node(
        home, FileIdentity.loadOrCreate(home), platform,
        Settings.Defaults("KtPhone", mapOf("Internal" to share), File(home, "downloads").path, 1),
    )
    node.updateShares(mapOf("Internal" to share))
    node.updateSyncFolders(listOf(SyncFolder("docs", syncDir)))
    node.start(withDiscovery = false)
    emit("READY ${node.identity.id}")

    val stdin = System.`in`.bufferedReader()
    while (true) {
        val line = stdin.readLine() ?: break
        val parts = line.split(" ", limit = 3)
        try {
            when (parts[0]) {
                "pair" -> {
                    val s = node.startPairing(address = parts[1])
                    emit("SAS ${s.peerId} ${s.sas}")
                }
                "confirm" -> {
                    node.confirmPairing(parts[1], true)
                    emit("OK")
                }
                "clip" -> {
                    node.onLocalClipboard(parts[1])
                    emit("OK")
                }
                "send" -> {
                    val f = File(parts[2])
                    val saved = node.sendFile(parts[1], f.name) { FileInputStream(f) }
                    emit("SENT $saved")
                }
                "ls" -> {
                    val fs = RemoteFs(node, parts[1])
                    emit("LS " + fs.list(parts[2]).map { it.name + if (it.dir) "/" else "" }.sorted().joinToString(","))
                }
                "get" -> {
                    val (peer, rest) = parts[1] to parts[2]
                    val (remote, local, off, len) = rest.split(" ")
                    val fs = RemoteFs(node, peer)
                    FileOutputStream(local).use { fs.read(remote, off.toLong(), len.toLong(), it) }
                    emit("OK")
                }
                "put" -> {
                    val (remote, local) = parts[2].split(" ")
                    FileInputStream(local).use { RemoteFs(node, parts[1]).write(remote, it) }
                    emit("OK")
                }
                "mv" -> {
                    val (a, b) = parts[2].split(" ")
                    RemoteFs(node, parts[1]).move(a, b)
                    emit("OK")
                }
                "mkdir" -> {
                    RemoteFs(node, parts[1]).mkdir(parts[2])
                    emit("OK")
                }
                "rm" -> {
                    RemoteFs(node, parts[1]).delete(parts[2])
                    emit("OK")
                }
                "connected" -> emit("CONNECTED " + node.connected().joinToString(",") { it.peerId })
                "rescan" -> {
                    node.rescan()
                    emit("OK")
                }
                "drop" -> {
                    node.session(parts[1])?.channel?.close()
                    emit("OK")
                }
                "reconnect" -> {
                    node.reconnectAll()
                    emit("OK")
                }
                "unpair" -> {
                    node.unpair(parts[1])
                    emit("OK")
                }
                "quit" -> break
                else -> emit("ERR unknown command")
            }
        } catch (e: Exception) {
            emit("ERR ${e.javaClass.simpleName}: ${e.message}")
        }
    }
    node.stop()
}
