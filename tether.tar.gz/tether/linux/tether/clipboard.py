"""Desktop clipboard backends.

On GNOME (Wayland or X11) the shell extension owns clipboard access and talks
to the daemon over the control socket, because Mutter does not let ordinary
background clients watch the clipboard. Elsewhere we fall back to
wl-clipboard (wlroots and KDE Wayland) or xclip (X11).
"""

import asyncio
import logging
import os
import shutil

log = logging.getLogger("tether.clipboard")

MAX_TEXT = 1024 * 1024


class Backend:
    name = "none"

    def __init__(self, on_change):
        self.on_change = on_change  # callable(text)

    async def start(self):
        pass

    async def set(self, text: str) -> None:
        pass

    @property
    def available(self) -> bool:
        return False


class ExtensionBackend(Backend):
    """Driven by the GNOME Shell extension via the control socket."""

    name = "gnome-extension"

    def __init__(self, on_change):
        super().__init__(on_change)
        self.clients: set = set()  # control connections that registered as clipboard providers

    @property
    def available(self) -> bool:
        return bool(self.clients)

    async def set(self, text: str) -> None:
        for c in list(self.clients):
            await c.push({"ev": "clip_set", "text": text})


class WlBackend(Backend):
    name = "wl-clipboard"

    @property
    def available(self) -> bool:
        return True

    async def start(self):
        asyncio.ensure_future(self._watch())

    async def _watch(self):
        while True:
            # wl-paste runs the given command for every change; we print a marker and re-read.
            proc = await asyncio.create_subprocess_exec(
                "wl-paste", "--type", "text", "--watch", "sh", "-c", "echo x",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL,
            )
            while await proc.stdout.readline():
                text = await self._read()
                if text is not None:
                    self.on_change(text)
            await proc.wait()
            await asyncio.sleep(2)

    async def _read(self):
        proc = await asyncio.create_subprocess_exec(
            "wl-paste", "--no-newline", "--type", "text",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL,
        )
        out, _ = await proc.communicate()
        if proc.returncode != 0 or len(out) > MAX_TEXT:
            return None
        return out.decode("utf-8", "replace")

    async def set(self, text: str) -> None:
        proc = await asyncio.create_subprocess_exec(
            "wl-copy", "--type", "text/plain;charset=utf-8", stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.communicate(text.encode())


class XclipBackend(Backend):
    name = "xclip"

    @property
    def available(self) -> bool:
        return True

    async def start(self):
        asyncio.ensure_future(self._poll())

    async def _poll(self):
        last = await self._read()
        while True:
            await asyncio.sleep(1)
            text = await self._read()
            if text is not None and text != last:
                last = text
                self.on_change(text)

    async def _read(self):
        proc = await asyncio.create_subprocess_exec(
            "xclip", "-o", "-selection", "clipboard", "-t", "UTF8_STRING",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL,
        )
        out, _ = await proc.communicate()
        if proc.returncode != 0 or len(out) > MAX_TEXT:
            return None
        return out.decode("utf-8", "replace")

    async def set(self, text: str) -> None:
        proc = await asyncio.create_subprocess_exec(
            "xclip", "-i", "-selection", "clipboard", stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.communicate(text.encode())


def choose(kind: str, on_change) -> Backend:
    desktop = os.environ.get("XDG_CURRENT_DESKTOP", "")
    if kind == "auto":
        if "GNOME" in desktop.upper():
            kind = "gnome-extension"
        elif os.environ.get("WAYLAND_DISPLAY") and shutil.which("wl-paste"):
            kind = "wl-clipboard"
        elif os.environ.get("DISPLAY") and shutil.which("xclip"):
            kind = "xclip"
        else:
            kind = "gnome-extension"
    cls = {"gnome-extension": ExtensionBackend, "wl-clipboard": WlBackend, "xclip": XclipBackend}.get(kind, Backend)
    log.info("clipboard backend: %s", cls.name)
    return cls(on_change)
